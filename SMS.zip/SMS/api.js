// src/api.js
import express from 'express';
const router = express.Router();
import { CleanKeyElemnts, loadIK, LoadSPK, publishIK } from './controllers/IKController.js';
import { publishSPK } from './controllers/SPKController.js';
import { checkLinkCode, CleanLinkeDevice, LinkDeviceData } from './controllers/LinkDeviceController.js';
import { getSPKUsers, LoadIKSPK, LoadUserIK } from './controllers/KeyController.js';
import { NewAction,AccountibilityList } from './controllers/AccountibilityController.js';

// Define the POST endpoint
router.post('/LoadUserIK', LoadUserIK);
router.post('/publishIK', publishIK);
router.post('/loadIk', loadIK);
router.post('/LoadSPK', LoadSPK);
router.post('/publishSPK', publishSPK);
router.post('/CleanKeyElemnts', CleanKeyElemnts);
router.post('/LinkDeviceData', LinkDeviceData);
router.post('/CleanLinkeDevice', CleanLinkeDevice);
router.post('/checkLinkCode', checkLinkCode);
router.post('/LoadIKSPK', LoadIKSPK);
router.post('/getSPKUsers', getSPKUsers);
router.post('/NewAction', NewAction);
router.get('/Accountibility', AccountibilityList);



export  default  router;
