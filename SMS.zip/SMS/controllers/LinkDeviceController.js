
import db from "../db.js";
import IK from "../models/IK.js";
import LinkDevice from "../models/LinkDevice.js";
import SPK from "../models/SPK.js";
export const LinkDeviceData =async  (req, res) => {

        await LinkDevice.query().where('link_code',req.body.previousHash).delete();
        await LinkDevice.query().where('device_id',req.body.device_id).delete();
   const row= await LinkDevice.query().create({
       link_code:req.body.code,device_id:req.body.device_id,ek:req.body.ek
    });
    res.json({success:true});
}
export const CleanLinkeDevice =async  (req, res) => {
   // await LinkDevice.query().where('uid',req.body.uid).delete();
     res.json({success:true});
}
export const checkLinkCode =async  (req, res) => {
const check=    await LinkDevice.query().where('link_code',req.body.link_code).count();
console.log(check);
if(check>0){
  const linkData=await LinkDevice.query().where('link_code',req.body.link_code).first();
  await LinkDevice.query().where('link_code',req.body.link_code).delete();
const uid=req.body.uid;
  res.json({success:true,linkData});
  return;
}

     res.json({success:false});
}