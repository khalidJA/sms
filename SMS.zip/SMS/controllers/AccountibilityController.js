
import db from "../db.js";
import Accountibility from "../models/Accountibility.js";
import IK from "../models/IK.js";
import SPK from "../models/SPK.js";
import SQL from "../models/SQL.js";
import XSS from "../models/XSS.js";
export const NewAction =async  (req, res) => {
    const result=await isMalicious(req.body.data)
   const result_msg= result.isSafe==true?'Safe Content':'This file may be malicious.'
    const ik=await Accountibility.query().create({
        uid:req.body.uid,action:req.body.action,result:result_msg,data:req.body.data,
        similarity:result.similarity,type:result.type
    })
     res.json({success:true});
 }



 function levenshteinDistance(a, b) {

    const matrix = Array.from({ length: a.length + 1 }, () => []);
    for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
    for (let j = 0; j <= b.length; j++) matrix[0][j] = j;

    for (let i = 1; i <= a.length; i++) {
        for (let j = 1; j <= b.length; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            matrix[i][j] = Math.min(
                matrix[i - 1][j] + 1,
                matrix[i][j - 1] + 1,
                matrix[i - 1][j - 1] + cost
            );
        }
    }
    return matrix[a.length][b.length];
}

// Function to check for similarity
export const  isMalicious=async (data)=> {
    let type=null;
    let similarity=null
    if(data==null || data==undefined|| data=='')
        return { isSafe: true, type: null, similarity:0 };
    const similarityThreshold = 0.3; // Define a threshold, e.g., 30% similarity
   const  sqlInjectionDataset=await SQL.query().get();
    const xssDataset=await XSS.query().get();
    const datasets = [
        { type: "SQL Injection", codes: sqlInjectionDataset },
        { type: "XSS", codes: xssDataset }
    ];

    for (const dataset of datasets) {
        for (const code of dataset.codes) {
            const distance = levenshteinDistance(data, code.data);
            const checked_similarity = 1 - distance / Math.max(data.length, code.data.length);

            if (checked_similarity >= similarityThreshold) {
                type=dataset.type
                similarity= checked_similarity
                return { isSafe: false, type: dataset.type, similarity };
            }
        }
    }

    return { isSafe: true,similarity,type };
}

export const AccountibilityList = async (req, res) => {
    console.log("sSS")
    try {
        const data = await db.raw('select * from accountibility');
        const records=data[0];
        res.render('accountibilityList', { success: true, records});
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
