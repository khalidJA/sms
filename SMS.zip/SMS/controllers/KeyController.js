
import db from "../db.js";
import IK from "../models/IK.js";
import SPK from "../models/SPK.js";
export const LoadUserIK =async  (req, res) => {
    const ik=await IK.query().where('uid',req.body.uid).first();
     res.json({success:true,ik});
 }
export const LoadIKSPK =async  (req, res) => {
    const check1=await IK.query().where('uid',req.body.uid).count();
    const check2=await IK.query().where('uid',req.body.uid).count();
    const ik=await IK.query().where('uid',req.body.uid).first();
    const spk=await SPK.query().where('uid',req.body.uid).first();
 
     res.json({success:check1>0 && check2>0,ik,spk});
 }
export const getSPKUsers =async  (req, res) => {
    const spks = {};
    for (const uid of req.body.users) {
        console.log(uid);
        const spk = await SPK.query().where('uid', uid).first();
        console.log(spk);
        spks[uid]=spk;
    }
    res.json({success:true ,spks});
 }