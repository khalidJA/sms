import db from "../db.js";
import IK from "../models/IK.js";

import SPK from "../models/SPK.js";


export const publishIK =async  (req, res) => {
    const data=req.body;
IK.query().create({
    salt:data.salt,
    public:data.public,
    uid:data.uid
})
res.json({success:true});

}

export const loadIK =async  (req, res) => {
   const check=await IK.query().where('uid',req.body.uid).count();
   const ik=await IK.query().where('uid',req.body.uid).first();

    res.json({success:check>0,ik:ik});
}
export const LoadSPK =async  (req, res) => {
   const check=await SPK.query().where('uid',req.body.uid).count();
   const spk=await SPK.query().where('uid',req.body.uid).get();
    res.json({success:check>0,spk:spk});
}

export const CleanKeyElemnts =async  (req, res) => {
     await IK.query().where('uid',req.body.uid).delete();
     await SPK.query().where('uid',req.body.uid).delete();
     res.json({success:true});
}
