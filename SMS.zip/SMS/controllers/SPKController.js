import db from "../db.js";
import SPK from "../models/SPK.js";
export const publishSPK  =async  (req, res) => {
    const data=req.body;
    data.spk.map((spk)=>{
        SPK.query().create({
            salt:spk.salt,
            public:spk.pu,
            signature:spk.signature,
            uid:data.uid
        });
    })

res.json({success:true});
}