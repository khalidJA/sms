import { sutando } from 'sutando';

// Add SQL Connection Info
sutando.addConnection({
  client: 'mysql',
  connection: {
    host : '127.0.0.1',
    port : 3306,
    user : 'root',
    password : '',
    database : 'server1_sms'
  },
});

const db = sutando.connection();
export default db;