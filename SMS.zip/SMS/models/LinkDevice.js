import { HasUniqueIds, compose, Model } from "sutando";

export default class LinkDevice extends compose(Model, HasUniqueIds) {
    table = 'linked_devices';
  
}
