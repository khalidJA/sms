import { HasUniqueIds, compose, Model } from "sutando";

export default class IK extends compose(Model, HasUniqueIds) {
    table = 'ik';
  
}
