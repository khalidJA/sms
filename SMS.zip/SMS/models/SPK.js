import { HasUniqueIds, compose, Model } from "sutando";

export default class SPK extends compose(Model, HasUniqueIds) {
    table = 'spk';
  
}
