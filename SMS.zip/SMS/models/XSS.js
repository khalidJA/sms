import { HasUniqueIds, compose, Model } from "sutando";

export default class XSS extends compose(Model, HasUniqueIds) {
    table = 'xss';
  
}
