import { HasUniqueIds, compose, Model } from "sutando";

export default class Accountibility extends compose(Model, HasUniqueIds) {
    table = 'accountibility';
  
}
