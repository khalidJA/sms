import { HasUniqueIds, compose, Model } from "sutando";

export default class SQL extends compose(Model, HasUniqueIds) {
    table = 'sql_injection';
  
}
