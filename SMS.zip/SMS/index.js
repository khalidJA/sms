// src/index.js
// src/index.js
import http from 'http';

import express from 'express';
import cors from 'cors';
import apiRoutes from './api.js';
import setupSocket from './sockets.js';

const app = express();
const server = http.createServer({}, app);

// Middleware
app.use(cors());
app.use(express.json());

// Use the API routes
app.use('/api', apiRoutes);
app.set('view engine', 'ejs');

// Define the path to your views directory
app.set('views', './views');
// Setup socket operations
export const io=setupSocket(server);

// Start the server
const port = process.env.PORT || 3101;
server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
