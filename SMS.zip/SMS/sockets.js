// src/sockets.js
// ES Modules import style
import { Server as SocketIOServer } from 'socket.io';


function setupSocket(server) {
    const io = new SocketIOServer(server, {
        cors: {
            origin: 'https://localhost:3000',
            methods: ['GET', 'POST'],
            credentials: true // Enable credentials if needed
        }
    });

    io.on('connection', (socket) => {
        console.log('A user connected1');

        socket.on('disconnect', () => {
            console.log('User disconnected');
        });

        // Example custom event
        socket.on('customEvent', (data) => {
            console.log('Custom event received:', data);
            socket.emit('customEventResponse', { message: 'Data received' });
        });
    });

    return io;
}

export default setupSocket;
